/*
 Author: Nadim Ramrattan
 This class contains unit tests for the PlayerManager class.
 Each test verifies that one part of the NBA Legends DMS logic produces the expected result.
 The tests use dummy NBAPlayer objects instead of user input.
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class PlayerManagerTest {

    // PlayerManager object used by each test
    private PlayerManager manager;

    // Sample NBAPlayer objects used as test data
    private NBAPlayer jordan;
    private NBAPlayer lebron;

    /*
     Runs before every individual test.
     A new empty ArrayList and PlayerManager are created before
     */
    @BeforeEach
    public void setUp() {

        ArrayList<NBAPlayer> players = new ArrayList<>();

        manager = new PlayerManager(players);

        jordan = new NBAPlayer(
                1,
                "Michael Jordan",
                "Chicago Bulls",
                "SG",
                30.1,
                6.2,
                5.3,
                6
        );

        lebron = new NBAPlayer(
                2,
                "LeBron James",
                "Los Angeles Lakers",
                "SF",
                27.0,
                7.5,
                7.4,
                4
        );
    }

    /*
     Tests whether a valid player can be added.
     */
    @Test
    public void testAddPlayer() {

        boolean added = manager.addPlayer(jordan);

        assertTrue(added);
        assertEquals(1, manager.getPlayers().size());
        assertNotNull(manager.findPlayer(1));
        assertEquals("Michael Jordan", manager.findPlayer(1).getName());
    }

    /*
     Tests whether duplicate Player IDs are rejected.
     */
    @Test
    public void testDuplicatePlayerCannotBeAdded() {

        manager.addPlayer(jordan);

        NBAPlayer duplicatePlayer = new NBAPlayer(
                1,
                "Duplicate Player",
                "Miami Heat",
                "SG",
                20.0,
                4.0,
                3.0,
                1
        );

        boolean added = manager.addPlayer(duplicatePlayer);

        assertFalse(added);
        assertEquals(1, manager.getPlayers().size());
        assertEquals("Michael Jordan", manager.findPlayer(1).getName());
    }

    /*
     Tests whether an existing player can be removed.
     */
    @Test
    public void testRemovePlayer() {

        manager.addPlayer(jordan);

        boolean removed = manager.removePlayer(1);

        assertTrue(removed);
        assertNull(manager.findPlayer(1));
        assertEquals(0, manager.getPlayers().size());
    }

    /*
     Tests an attempt to remove a player that does not exist.
     */
    @Test
    public void testRemovePlayerThatDoesNotExist() {

        boolean removed = manager.removePlayer(99);

        assertFalse(removed);
        assertEquals(0, manager.getPlayers().size());
    }

    /*
     Tests whether all fields of an existing player can be updated.
     */
    @Test
    public void testUpdateAllPlayerFields() {

        manager.addPlayer(jordan);

        boolean updated = manager.updatePlayer(
                1,
                "Michael Jordan",
                "Washington Wizards",
                "SG",
                29.5,
                6.0,
                5.0,
                6
        );

        NBAPlayer updatedPlayer = manager.findPlayer(1);

        assertTrue(updated);
        assertNotNull(updatedPlayer);
        assertEquals("Michael Jordan", updatedPlayer.getName());
        assertEquals("Washington Wizards", updatedPlayer.getTeam());
        assertEquals("SG", updatedPlayer.getPosition());
        assertEquals(29.5, updatedPlayer.getPpg(), 0.001);
        assertEquals(6.0, updatedPlayer.getRpg(), 0.001);
        assertEquals(5.0, updatedPlayer.getApg(), 0.001);
        assertEquals(6, updatedPlayer.getChampionships());
    }

    /*
     Tests whether one individual field can be updated.
     This matches the improved update menu, where the user can
     select one field instead of retyping the entire record.
     */
    @Test
    public void testUpdateSingleField() {

        manager.addPlayer(jordan);

        boolean updated = manager.updatePpg(1, 31.0);

        NBAPlayer updatedPlayer = manager.findPlayer(1);

        assertTrue(updated);
        assertEquals(31.0, updatedPlayer.getPpg(), 0.001);
        assertEquals("Chicago Bulls", updatedPlayer.getTeam());
        assertEquals(6, updatedPlayer.getChampionships());
    }

    /*
      Tests an attempt to update a player that does not exist.
     */
    @Test
    public void testUpdatePlayerThatDoesNotExist() {

        boolean updated = manager.updatePpg(99, 25.0);

        assertFalse(updated);
    }
    /*
     Tests whether displayPlayers() returns a String containing
     every player currently stored in the system.
     */
    @Test
    public void testDisplayPlayers() {

        manager.addPlayer(jordan);
        manager.addPlayer(lebron);

        String output = manager.displayPlayers();

        assertTrue(output.contains("Michael Jordan"));
        assertTrue(output.contains("LeBron James"));
        assertTrue(output.contains("Chicago Bulls"));
        assertTrue(output.contains("Los Angeles Lakers"));
    }

    /*
     Tests the custom comparison feature.
     */
    @Test
    public void testComparePlayers() {

        manager.addPlayer(jordan);
        manager.addPlayer(lebron);

        String result = manager.comparePlayers(1, 2);

        assertTrue(result.contains("Michael Jordan"));
        assertTrue(result.contains("LeBron James"));

        assertTrue(result.contains("Points Per Game Winner: Michael Jordan"));
        assertTrue(result.contains("Rebounds Per Game Winner: LeBron James"));
        assertTrue(result.contains("Assists Per Game Winner: LeBron James"));
        assertTrue(result.contains("Championships Winner: Michael Jordan"));
    }

    /*
     Tests comparing players when one ID does not exist.
     */
    @Test
    public void testComparePlayersInvalidID() {

        manager.addPlayer(jordan);

        String result = manager.comparePlayers(1, 99);

        assertEquals(
                "One or both Player IDs were not found.",
                result
        );
    }

    /*
      Tests loading a valid player text file.
      This test assumes players.txt is located in
      the project's root directory.
     */
    @Test
    public void testLoadPlayersFile() {
        FileManager fileManager = new FileManager();

        ArrayList<NBAPlayer> players =
                fileManager.loadFile("players.txt");

        assertNotNull(players);

        assertEquals(20, players.size());

        assertEquals(
                "Michael Jordan",
                players.get(0).getName()
        );
    }

    /*
     Tests attempting to load a file that does not exist.
     */
    @Test
    public void testLoadInvalidFile() {

        FileManager fileManager = new FileManager();

        ArrayList<NBAPlayer> players =
                fileManager.loadFile("ThisFileDoesNotExist.txt");

        assertNotNull(players);

        assertEquals(0, players.size());
    }

    /*
     Tests adding and removing multiple players.
     */
    @Test
    public void testMultiplePlayers() {

        manager.addPlayer(jordan);
        manager.addPlayer(lebron);

        assertEquals(2, manager.getPlayers().size());

        manager.removePlayer(1);

        assertEquals(1, manager.getPlayers().size());

        assertEquals(
                "LeBron James",
                manager.getPlayers().get(0).getName()
        );
    }

    /*
     Tests attempting to add a null player.
     */
    @Test
    public void testAddNullPlayer() {

        assertFalse(manager.addPlayer(null));

    }

}